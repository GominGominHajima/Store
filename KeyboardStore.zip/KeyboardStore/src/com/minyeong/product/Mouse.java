package com.minyeong.product;

public class Mouse extends Product {
	
	public Mouse(String xx, int yy) {
		super(xx, yy);
	}

}
