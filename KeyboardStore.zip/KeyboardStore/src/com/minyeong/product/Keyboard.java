package com.minyeong.product;

public class Keyboard extends Product {
	
	public Keyboard(String xx, int yy) {
		super(xx, yy);
	}

}
