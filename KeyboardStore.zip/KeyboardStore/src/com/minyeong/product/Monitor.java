package com.minyeong.product;

public class Monitor extends Product {
	
	public Monitor(String xx, int yy) {
		super(xx, yy);
	}

}
