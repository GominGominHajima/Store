package com.minyeong.keyboard;

import com.minyeong.product.Keyboard;
import com.minyeong.product.Product;

public class ProcMenuKeyboard {
	
	public static void run() {
		
		for(Product p:KioskObj.products) {
			if(p instanceof Keyboard) {
				System.out.println(p.name+" "+p.price +"원");
			}
		}
		yy:while(true) {
			
			System.out.println("[1.씽크웨이/2.커세어/3.덱/X.이전메뉴");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
				case "1":
					System.out.println(KioskObj.products.get(0).name+" 선택됨");
					KioskObj.basket.add(new Order(KioskObj.products.get(0)));
					break;
				case "2":
					System.out.println(KioskObj.products.get(1).name+" 선택됨");
					KioskObj.basket.add(new Order(KioskObj.products.get(1)));
					break;
				case "3":
					System.out.println(KioskObj.products.get(2).name+" 선택됨");
					KioskObj.basket.add(new Order(KioskObj.products.get(2)));
					break;
				case "x":
					System.out.println("이전 메뉴 이동");
					break yy;
			}
		}
	}

}

