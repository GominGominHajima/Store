package com.minyeong.keyboard;

import com.minyeong.product.Monitor;
import com.minyeong.product.Product;

public class PrucMenuMonitor {
	
	public static void run() {
		
		for(Product p:KioskObj.products) {
			if(p instanceof Monitor) {
				System.out.println(p.name+" "+p.price +"원");
			}
		}
		yy:while(true) {
			System.out.println("[1.ASUS/2.DELL/3.BEN-Q/x.이전메뉴");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
			case "1":
				System.out.println(KioskObj.products.get(3).name+" 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(3)));
				break;
			case "2":
				System.out.println(KioskObj.products.get(4).name+" 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(4)));
				break;
			case "3":
				System.out.println(KioskObj.products.get(5).name+" 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(5)));
				break;
			case "x":
				System.out.println("이전 메뉴 이동");
				break yy;
			}
		}
		
	}

}
