package com.minyeong.keyboard;

import java.util.ArrayList;
import java.util.Scanner;

import com.minyeong.product.Keyboard;
import com.minyeong.product.Monitor;
import com.minyeong.product.Mouse;
import com.minyeong.product.Product;

public class KioskObj {
	public static ArrayList<Order> basket = new ArrayList<>();
	public static ArrayList<Product> products = new ArrayList<>();
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;
	
	public static void productLoad() {
		//키보드
		products.add(new Keyboard("씽크웨이 토체티 무소음 적축",146000));
		products.add(new Keyboard("커세어 K100",342000));
		products.add(new Keyboard("덱 거북선",174000));
		//모니터
		products.add(new Monitor("ASUS 스위프트",2000000));
		products.add(new Monitor("DELL 에일리언웨어",2099000));
		products.add(new Monitor("BEN-Q 모비우스",990000));
		//마우스
		products.add(new Mouse("로지텍 지슈라",199000));
		products.add(new Mouse("레이져 바이퍼",194000));
		products.add(new Mouse("로켓 코네 프로",99000));
	}

}
