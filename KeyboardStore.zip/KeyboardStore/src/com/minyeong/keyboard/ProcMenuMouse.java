package com.minyeong.keyboard;

import com.minyeong.product.Mouse;
import com.minyeong.product.Product;

public class ProcMenuMouse {
	
	public static void run() {
		
		for(Product p:KioskObj.products) {
			if(p instanceof Mouse) {
				System.out.println(p.name+" "+p.price +"원");
			}
		}
		yy:while(true) {
			
			System.out.println("[1.로지텍/2.레이져/3.로켓/x.이전메뉴");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
			case "1":
				System.out.println(KioskObj.products.get(6).name+" 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(6)));
				break;
			case "2":
				System.out.println(KioskObj.products.get(7).name+" 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(7)));
				break;
			case "3":
				System.out.println(KioskObj.products.get(8).name+" 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(8)));
				break;
			case "x":
				System.out.println("이전 메뉴 이동");
				break yy;
			}
		}
		
	}

}
