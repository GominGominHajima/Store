package com.minyeong.keyboard;

import com.minyeong.product.Product;

public class Order {
	
	public Product selectedProduct;
	
	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}
	
//	public Order1(Product selectedProduct) {
//		this.selectedProduct = selectedProduct;
//	}

}
