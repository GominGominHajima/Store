package com.minyeong.keyboard;

public class Disp {
	
		String x = "x";
		
		final static String DOT = "〓";
		final static int DOT_COUNT = 38;
		public static void line() {
			for(int i=0;i<DOT_COUNT;i=i+1) {
				System.out.print(DOT);
			}
			System.out.println();
		}
		
		public static void title() {
			line();
			dot(10);
			System.out.println("게임용품 스토어 (v."+Kiosk.VERSION+" by 나) ");
			dot(10);
			System.out.println();
			line();
		}
		
		public static void dot(int n) {
			for(int i=0;i<n;i++) {
				System.out.print(DOT);
			}
	}

}
