package com.minyeong.keyboard;

public class Kiosk {
	
	public static final String VERSION = "0.0.1";
	
	void run() {
		KioskObj.productLoad();
		Disp.title();
		xx:while(true) {
			System.out.println("명령 입력[1.키보드/2.마우스/3.모니터/e.프로그램종료");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
			case "1":
				ProcMenuKeyboard.run();
				break;
			case "2":
				ProcMenuMouse.run();
				break;
			case "3":
				PrucMenuMonitor.run();
				break;
			case "e":
				System.out.println("장바구니에 담긴 상품 갯수:"+KioskObj.basket.size());
				int sum = 0;
				for(Order o:KioskObj.basket) {
					sum = sum + o.selectedProduct.price;
				}
				System.out.println("계산하실 금액은 :"+sum+"원 입니다.");
				
				System.out.println("====================");
				for(Order o:KioskObj.basket) {
					System.out.println(o.selectedProduct.name);
				}
				System.out.println("====================");
				System.out.println("프로그램종료");
				break xx;
				
		}
	}

	}
}