package com.minyeong.keyboard;

public class Main {

	public static void main(String[] args) {
		Kiosk K = new Kiosk();
		K.run();
	}

}
